package com.droid.dolphy

import android.content.Context
import android.content.SharedPreferences
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.droid.dolphy.plugin.PluginManager
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
internal data class HomeDesign(
    val title: String = "Dolphy",
    val symbol: String = "🐬",
    val accent: String = "137AAD",
    val customSplash: Boolean = false,
    val customHome: Boolean = false,
    val grid: Boolean = false,
    val rounded: Boolean = true,
    val tiles: List<String> = listOf("stock_bluetooth", "stock_modules", "plugin_manager"),
    val labels: Map<String, String> = emptyMap()
) {
    fun color(): Color = runCatching { Color(android.graphics.Color.parseColor("#" + accent)) }
        .getOrDefault(Color(0xFF137AAD))
}

@Composable
internal fun rememberHomeDesign(): Pair<HomeDesign, (HomeDesign) -> Unit> {
    val context = LocalContext.current
    val prefs = remember(context) { context.getSharedPreferences("home_design_v1", Context.MODE_PRIVATE) }
    fun read() = runCatching { Json.decodeFromString<HomeDesign>(prefs.getString("layout", "") ?: "") }.getOrDefault(HomeDesign())
    var current by remember(prefs) { mutableStateOf(read()) }
    DisposableEffect(prefs) {
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key -> if (key == "layout") current = read() }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        onDispose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }
    return current to { next ->
        current = next
        prefs.edit().putString("layout", Json.encodeToString(next)).apply()
    }
}

@Composable internal fun DesignerSplash(d: HomeDesign) {
    Box(Modifier.fillMaxSize().background(Color(0xFF101318)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(d.symbol, style = MaterialTheme.typography.displayLarge, color = d.color())
            Text(d.title, style = MaterialTheme.typography.headlineLarge, color = Color.White)
        }
    }
}

@Composable private fun choices(): Map<String, FunctionDestination> {
    val sections = functionDestinationSections()
    val defaults = listOf("stock_bluetooth" to "Bluetooth", "stock_modules" to "All tools",
        "plugin_manager" to "Plugins & AI Studio", "settings" to "Settings")
    return (defaults.map { (route, title) -> FunctionDestination(
        com.droid.dolphy.plugin.PluginIcons.resolve("extension"), title, "", route, "HOME")
    } + sections.flatMap { it.second }).associateBy { it.route }
}

@Composable internal fun DesignerHome(nav: NavController) {
    val d = rememberHomeDesign().first
    val catalog = choices()
    val ctx = LocalContext.current
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(16.dp, 24.dp, 16.dp, 120.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text(d.title, style = MaterialTheme.typography.headlineLarge) }
        item { OutlinedButton(onClick = { nav.navigate("ui_designer") }) { Text("Edit home") } }
        items(d.tiles.mapNotNull(catalog::get).chunked(if (d.grid) 2 else 1)) { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { item ->
                    val bg = d.color()
                    Button(onClick = { openFunctionDestination(item, nav, ctx) }, modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(if (d.rounded) 24.dp else 3.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = bg, contentColor =
                            if (androidx.core.graphics.ColorUtils.calculateLuminance(android.graphics.Color.parseColor("#"+d.accent)) > 0.179) Color.Black else Color.White)) {
                        Text(d.labels[item.route]?.ifBlank { item.title } ?: item.title)
                    }
                }
                if (d.grid && row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable internal fun HomeDesigner(nav: NavController) {
    val (d, save) = rememberHomeDesign()
    val catalog = choices()
    val loaded by PluginManager.plugins.collectAsState()
    val hasPlugin = loaded.any { it.manifest.id == "dolphy_startup_designer" && it.enabled }
    var filter by rememberSaveable { mutableStateOf("") }
    var hex by rememberSaveable(d.accent) { mutableStateOf(d.accent) }
    var showReset by rememberSaveable { mutableStateOf(false) }
    var editing by rememberSaveable { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            nav.currentBackStackEntry?.savedStateHandle?.set("plugin_preview_uri", uri.toString())
            nav.navigate("plugin_file_preview")
        }
    }
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(16.dp, 18.dp, 16.dp, 130.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            TextButton(onClick = { nav.popBackStack() }) { Text("Back") }
            Text("Design my UI", style = MaterialTheme.typography.headlineMedium)
            Text("Changes save on this phone. Switch off Custom home to return to the original screen.")
            DesignSwitch("Custom home", d.customHome) { save(d.copy(customHome = it)) }
            DesignSwitch("Two-column tiles", d.grid) { save(d.copy(grid = it)) }
            DesignSwitch("Rounded buttons", d.rounded) { save(d.copy(rounded = it)) }
            OutlinedTextField(d.title, { save(d.copy(title = it.take(64))) }, singleLine = true, label = { Text("Home and startup title") })
            OutlinedTextField(hex, {
                hex = it.trimStart('#').take(6).uppercase()
                if (hex.matches(Regex("[0-9A-F]{6}"))) save(d.copy(accent = hex))
            }, singleLine = true, label = { Text("Button and symbol colour · RRGGBB") })
            Text("Startup Designer plugin", style = MaterialTheme.typography.titleMedium)
            if (hasPlugin) {
                DesignSwitch("Custom startup graphic", d.customSplash) { save(d.copy(customSplash = it)) }
                OutlinedTextField(d.symbol, { save(d.copy(symbol = it.take(20))) }, singleLine = true, label = { Text("Startup symbol or emoji") })
                Box(Modifier.fillMaxWidth().height(125.dp)) { DesignerSplash(d) }
            } else Text("Enable Startup Designer in Plugin Manager for launch graphics.")
            Text("Home tiles", style = MaterialTheme.typography.titleLarge)
        }
        val visible = d.tiles.filter { it in catalog }
        items(visible, key = { "tile:"+it }) { id ->
            val index = visible.indexOf(id)
            val name = catalog.getValue(id).title
            Column {
                Text(d.labels[id]?.ifBlank { name } ?: name, style = MaterialTheme.typography.titleMedium)
                Row {
                    fun move(n: Int) {
                        val list = d.tiles.toMutableList()
                        java.util.Collections.swap(list, list.indexOf(id), list.indexOf(visible[n]))
                        save(d.copy(tiles = list))
                    }
                    TextButton(onClick = { move(index-1) }, enabled = index > 0) { Text("↑") }
                    TextButton(onClick = { move(index+1) }, enabled = index < visible.lastIndex) { Text("↓") }
                    TextButton(onClick = { editing = if (editing == id) null else id }) { Text("Name") }
                    TextButton(onClick = { save(d.copy(tiles = d.tiles - id)) }) { Text("Remove") }
                }
                if (editing == id) OutlinedTextField(d.labels[id].orEmpty(), {
                    save(d.copy(labels = d.labels + (id to it.take(64))))
                }, label = { Text(name) }, singleLine = true)
            }
        }
        item {
            Text("Add tools and plugins", style = MaterialTheme.typography.titleLarge)
            Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Import plugin file") }
            OutlinedButton(onClick = { nav.navigate("plugin_manager") }) { Text("Open Plugin Studio") }
            OutlinedTextField(filter, { filter = it }, label = { Text("Find a tile") }, singleLine = true)
        }
        items(catalog.values.filter { it.route !in d.tiles && it.title.contains(filter, true) }, key = { "add:"+it.route }) { dest ->
            OutlinedButton(onClick = { save(d.copy(tiles = d.tiles + dest.route)) }) { Text("+ " + dest.title) }
        }
        item { TextButton(onClick = { showReset = true }) { Text("Restore original layout") } }
    }
    if (showReset) AlertDialog(onDismissRequest = { showReset = false }, title = { Text("Restore original layout?") },
        text = { Text("This clears your saved layout. Installed plugins stay on this phone.") },
        confirmButton = { TextButton(onClick = { save(HomeDesign()); showReset = false }) { Text("Restore") } },
        dismissButton = { TextButton(onClick = { showReset = false }) { Text("Cancel") } })
}

@Composable private fun DesignSwitch(label: String, checked: Boolean, changed: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f)); Switch(checked = checked, onCheckedChange = changed)
    }
}

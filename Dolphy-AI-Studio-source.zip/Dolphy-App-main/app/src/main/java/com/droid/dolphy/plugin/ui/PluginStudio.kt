package com.droid.dolphy.plugin.ui

import android.content.Context
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.droid.dolphy.plugin.PluginManager
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Native, offline plugin editor with in-app installation and durable revision snapshots. */
private object StudioStore {
    private fun root(ctx: Context) = File(ctx.filesDir, "studio_versions").apply { mkdirs() }
    private fun safe(id: String) = id.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(64)
    fun revisions(ctx: Context, id: String): List<File> = File(root(ctx), safe(id))
        .listFiles()?.filter { it.extension == "dolphyplugin" }?.sortedByDescending { it.name } ?: emptyList()
    fun snapshot(ctx: Context, id: String, code: String): File {
        val dir = File(root(ctx), safe(id)).apply { mkdirs() }
        val name = "%013d_%s.dolphyplugin".format(System.currentTimeMillis(), java.util.UUID.randomUUID().toString().take(8))
        return File(dir, name).apply { writeText(code, Charsets.UTF_8) }
    }
    fun install(ctx: Context, id: String, code: String): Result<String> = runCatching {
        require(code.length in 1..512_000) { "Plugin source is empty or too large" }
        require(Regex("(?m)^__id__\\s*=").containsMatchIn(code)) { "Missing __id__" }
        require(Regex("(?m)^class\\s+\\w+\\(BasePlugin\\)").containsMatchIn(code)) { "Missing BasePlugin class" }
        val declared = Regex("""(?m)^__id__\s*=\s*['"]([a-zA-Z0-9_-]+)['"]\s*$""").find(code)?.groupValues?.get(1)
        require(declared == id && id == safe(id)) { "Plugin ID must match __id__ in the source" }
        val previous = PluginManager.plugins.value.firstOrNull { it.manifest.id == id }
        if (previous != null) snapshot(ctx, id, previous.sourceCode)
        val file = File(ctx.cacheDir, "studio_${safe(id)}.dolphyplugin")
        file.writeText(code, Charsets.UTF_8)
        val installed = PluginManager.installFromFile(file).getOrThrow()
        snapshot(ctx, installed.id, code)
        installed.id
    }
}

@Composable
fun PluginStudio() {
    val context = LocalContext.current
    var pluginId by remember { mutableStateOf("my_studio_plugin") }
    var pluginName by remember { mutableStateOf("My Studio Plugin") }
    var description by remember { mutableStateOf("A plugin made inside Dolphy") }
    var code by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Offline editor ready. Create a starter or paste Python plugin code.") }
    var refresh by remember { mutableIntStateOf(0) }
    val versions = remember(pluginId, refresh) { StudioStore.revisions(context, pluginId) }
    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Plugin Studio", style = MaterialTheme.typography.titleLarge)
        Text("Create, install, update and restore plugins without importing files.", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(pluginId, { pluginId = it }, label = { Text("Plugin ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(pluginName, { pluginName = it }, label = { Text("Plugin name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(description, { description = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth())
        val installed by PluginManager.plugins.collectAsState()
        var choose by remember { mutableStateOf(false) }
        TextButton(onClick = { choose = !choose }) { Text("Edit installed plugin") }
        if (choose) installed.filter { it.runtime == "python" }.forEach { plugin ->
            TextButton(onClick = {
                pluginId = plugin.manifest.id; pluginName = plugin.manifest.name
                code = plugin.sourceCode; choose = false
            }) { Text(plugin.manifest.name) }
        }
        GeneratorPanel(pluginId, code) { generated -> code = generated; message = "Draft ready. Review before installing." }
        Button(onClick = {
            val id = pluginId.replace(Regex("[^a-zA-Z0-9_]"), "_").ifBlank { "studio_plugin" }
            val name = pluginName.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
            val desc = description.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
            pluginId = id
            code = """__id__ = '$id'
__name__ = '$name'
__version__ = '1.0.0'
__author__ = 'Dolphy Studio'
__description__ = '$desc'
__icon__ = 'rounded:extension'
__permissions__ = []

class StudioPlugin(BasePlugin):
    def on_plugin_load(self):
        self.add_module('$name', '$desc', 'extension', 'main', 'OTHER', 10)

    def screen_main(self, ui, api, state):
        return ui.scaffold(title='$name', content=ui.lazy_column([
            ui.card([ui.text('$name', 'titleLarge'), ui.text('$desc', 'bodyMedium')])
        ], padding=16, spacing=12, fill_max_size=True))
"""
            message = "Starter generated. Review the code, then install."
        }) { Text("Create starter") }
        OutlinedTextField(code, { code = it }, label = { Text("Python plugin source") }, modifier = Modifier.fillMaxWidth().height(220.dp))
        Button(onClick = {
            val result = StudioStore.install(context, pluginId, code)
            message = result.fold({ "Installed: $it" }, { "Install failed: ${it.message}" })
            refresh++
        }, enabled = code.isNotBlank()) { Text("Save and install in Dolphy") }
        Text(message, style = MaterialTheme.typography.bodySmall)
        Text("Saved versions (${versions.size})", style = MaterialTheme.typography.titleMedium)
        versions.forEach { version ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(version.name.take(13).toLongOrNull() ?: 0L)), modifier = Modifier.weight(1f))
                TextButton(onClick = {
                    code = version.readText(Charsets.UTF_8)
                    message = "Version loaded. Press Save and install to restore it."
                }) { Text("Load") }
            }
        }

    }
}

@Composable
private fun GeneratorPanel(id: String, source: String, accept: (String) -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("studio_provider", Context.MODE_PRIVATE) }
    var endpoint by remember { mutableStateOf(prefs.getString("endpoint", "https://api.openai.com/v1").orEmpty()) }
    var model by remember { mutableStateOf(prefs.getString("model", "").orEmpty()) }
    var key by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val latestId by rememberUpdatedState(id)
    val latestSource by rememberUpdatedState(source)
    Text("AI plugin creator", style = MaterialTheme.typography.titleMedium)
    Text("Use a compatible chat-completions provider. Generate sends your request and the current plugin code to that provider. The key stays in memory.")
    OutlinedTextField(endpoint, { endpoint = it }, label = { Text("Provider HTTPS base URL") }, singleLine = true)
    OutlinedTextField(model, { model = it }, label = { Text("Model ID") }, singleLine = true)
    OutlinedTextField(key, { key = it }, label = { Text("Provider API key") }, singleLine = true,
        visualTransformation = PasswordVisualTransformation())
    OutlinedTextField(prompt, { prompt = it }, label = { Text("Describe your plugin or changes") })
    Button(enabled = !busy && prompt.isNotBlank() && model.isNotBlank(), onClick = {
        busy = true; error = ""
        val base = endpoint.trim().trimEnd('/')
        val selectedModel = model.trim()
        val token = key.trim()
        val request = prompt
        val current = source
        val target = id
        scope.launch {
            try {
                val generated = withContext(Dispatchers.IO) {
                    require(target.matches(Regex("[A-Za-z0-9_-]{1,64}"))) { "Choose a valid plugin ID first." }
                    val url = java.net.URL(base + "/chat/completions")
                    require(url.protocol == "https" && url.userInfo == null && url.query == null && url.ref == null) { "Use an HTTPS base URL." }
                    val instructions = "Write a complete Dolphy Python plugin. Return only Python. Use __id__ = '" + target +
                        "', __name__, __version__, __author__, __description__, __permissions__ = [], and a class inheriting BasePlugin. In on_plugin_load call self.add_module(title, description, 'extension', 'main', 'PLUGINS', 10). Implement screen_main(self, ui, api, state) returning ui.scaffold(title=title, content=ui.column([ui.text(title)] )). Only request permissions required by the user's plugin."
                    val messages = org.json.JSONArray()
                    fun add(role: String, content: String) { messages.put(org.json.JSONObject().put("role", role).put("content", content)) }
                    add("system", instructions)
                    add("user", request + "\nCurrent source:\n" + current)
                    val body = org.json.JSONObject().put("model", selectedModel).put("messages", messages)
                    val conn = url.openConnection() as javax.net.ssl.HttpsURLConnection
                    try {
                        conn.requestMethod = "POST"; conn.doOutput = true; conn.instanceFollowRedirects = false
                        conn.connectTimeout = 15000; conn.readTimeout = 90000
                        conn.setRequestProperty("Content-Type", "application/json")
                        if (token.isNotEmpty()) conn.setRequestProperty("Authorization", "Bearer " + token)
                        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                        val status = conn.responseCode
                        require(status in 200..299) { "Provider returned HTTP " + status + ". Check the URL, model, key and quota." }
                        val raw = conn.inputStream.bufferedReader().use { it.readText() }
                        val lines = org.json.JSONObject(raw).getJSONArray("choices").getJSONObject(0)
                            .getJSONObject("message").getString("content").trim().lines()
                        val result = (if (lines.first().startsWith("```") && lines.last() == "```") lines.drop(1).dropLast(1) else lines).joinToString("\n")
                        require(result.isNotBlank() && result.length <= 512000) { "Provider returned an empty or oversized draft." }
                        result
                    } finally { conn.disconnect() }
                }
                prefs.edit().putString("model", selectedModel).putString("endpoint", base).apply()
                if (latestId == target && latestSource == current) accept(generated) else error = "Editor changed. Generate again to use your latest draft."
            } catch (cancel: kotlinx.coroutines.CancellationException) { throw cancel }
            catch (e: Exception) { error = e.message ?: "Generation failed." }
            finally { busy = false }
        }
    }) { Text(if (busy) "Generating…" else "Generate draft") }
    if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
}

package com.droid.dolphy.plugin.ui

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.droid.dolphy.plugin.PluginManager
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Native, offline plugin editor with in-app installation and durable revision snapshots. */
private object StudioStore {
    private fun root(ctx: Context) = File(ctx.filesDir, "studio_versions").apply { mkdirs() }
    private fun safe(id: String) = id.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(64)
    fun revisions(ctx: Context, id: String): List<File> = File(root(ctx), safe(id))
        .listFiles()?.filter { it.extension == "dolphyplugin" }?.sortedByDescending { it.name } ?: emptyList()
    fun snapshot(ctx: Context, id: String, code: String): File {
        val dir = File(root(ctx), safe(id)).apply { mkdirs() }
        val name = "%013d_%s.dolphyplugin".format(System.currentTimeMillis(), java.util.UUID.randomUUID().toString().take(8))
        return File(dir, name).apply { writeText(code, Charsets.UTF_8) }
    }
    fun install(ctx: Context, id: String, code: String): Result<String> = runCatching {
        require(code.length in 1..512_000) { "Plugin source is empty or too large" }
        require(Regex("(?m)^__id__\\s*=").containsMatchIn(code)) { "Missing __id__" }
        require(Regex("(?m)^class\\s+\\w+\\(BasePlugin\\)").containsMatchIn(code)) { "Missing BasePlugin class" }
        val previous = PluginManager.plugins.value.firstOrNull { it.manifest.id == id }
        if (previous != null) snapshot(ctx, id, previous.sourceCode)
        val file = File(ctx.cacheDir, "studio_${safe(id)}.dolphyplugin")
        file.writeText(code, Charsets.UTF_8)
        val installed = PluginManager.installFromFile(file).getOrThrow()
        snapshot(ctx, installed.id, code)
        installed.id
    }
}

@Composable
fun PluginStudio() {
    val context = LocalContext.current
    var pluginId by remember { mutableStateOf("my_studio_plugin") }
    var pluginName by remember { mutableStateOf("My Studio Plugin") }
    var description by remember { mutableStateOf("A plugin made inside Dolphy") }
    var code by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Offline editor ready. Create a starter or paste Python plugin code.") }
    var refresh by remember { mutableIntStateOf(0) }
    val versions = remember(pluginId, refresh) { StudioStore.revisions(context, pluginId) }
    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Plugin Studio", style = MaterialTheme.typography.titleLarge)
        Text("Create, install, update and restore plugins without importing files.", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(pluginId, { pluginId = it }, label = { Text("Plugin ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(pluginName, { pluginName = it }, label = { Text("Plugin name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(description, { description = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            val id = pluginId.replace(Regex("[^a-zA-Z0-9_]"), "_").ifBlank { "studio_plugin" }
            val name = pluginName.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
            val desc = description.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
            pluginId = id
            code = """__id__ = '$id'
__name__ = '$name'
__version__ = '1.0.0'
__author__ = 'Dolphy Studio'
__description__ = '$desc'
__icon__ = 'rounded:extension'
__permissions__ = []

class StudioPlugin(BasePlugin):
    def on_plugin_load(self):
        self.add_module('$name', '$desc', 'extension', 'main', 'OTHER', 10)

    def screen_main(self, ui, api, state):
        return ui.scaffold(title='$name', content=ui.lazy_column([
            ui.card([ui.text('$name', 'titleLarge'), ui.text('$desc', 'bodyMedium')])
        ], padding=16, spacing=12, fill_max_size=True))
"""
            message = "Starter generated. Review the code, then install."
        }) { Text("Create starter") }
        OutlinedTextField(code, { code = it }, label = { Text("Python plugin source") }, modifier = Modifier.fillMaxWidth().height(220.dp))
        Button(onClick = {
            val result = StudioStore.install(context, pluginId, code)
            message = result.fold({ "Installed: $it" }, { "Install failed: ${it.message}" })
            refresh++
        }, enabled = code.isNotBlank()) { Text("Save and install in Dolphy") }
        Text(message, style = MaterialTheme.typography.bodySmall)
        Text("Saved versions (${versions.size})", style = MaterialTheme.typography.titleMedium)
        versions.take(25).forEach { version ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(version.name.take(13).toLongOrNull() ?: 0L)), modifier = Modifier.weight(1f))
                TextButton(onClick = {
                    code = version.readText(Charsets.UTF_8)
                    message = "Version loaded. Press Save and install to restore it."
                }) { Text("Load") }
            }
        }
        Text("AI generation requires a separately configured model service. This editor works offline.", style = MaterialTheme.typography.bodySmall)
    }
}
